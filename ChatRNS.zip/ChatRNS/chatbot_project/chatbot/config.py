import os
import google.generativeai as genai

# Set Gemini API Key
os.environ["GEMINI_API_KEY"] = "AIzaSyBKTrS68QkUKV2zQ7xHxDvf88RtwJs2PGM"
genai.configure(api_key=os.environ["GEMINI_API_KEY"])

# Create the model configuration
generation_config = {
    "temperature": 0.7,
    "top_p": 0.9,
    "top_k": 30,
    "max_output_tokens": 512,
    "response_mime_type": "text/plain",
}

model = genai.GenerativeModel(
    model_name="gemini-1.5-pro-002",
    generation_config=generation_config,
)
