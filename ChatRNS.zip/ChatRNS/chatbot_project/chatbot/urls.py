from django.urls import path
from . import views

urlpatterns = [
    path("", views.chatbot_home, name="chatbot_home"),
    path("generate-paragraph/", views.generate_paragraph, name="generate_paragraph"),
    path("generate-headline/", views.generate_headline, name="generate_headline"),
    path("enhance-text/", views.enhance_text, name="enhance_text"),
    path("humanize-text/", views.humanize_text, name="humanize_text"),
]
