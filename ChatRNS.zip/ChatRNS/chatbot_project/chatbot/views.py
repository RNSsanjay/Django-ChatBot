from django.shortcuts import render
from django.http import JsonResponse
from .config import model

def chatbot_home(request):
    return render(request, "chatbot/home.html")

def generate_paragraph(request):
    if request.method == "POST":
        topic = request.POST.get("topic")
        if topic.strip():
            try:
                chat_session = model.start_chat(history=[])
                response = chat_session.send_message(topic)
                return JsonResponse({"success": True, "text": response.text.strip()})
            except Exception as e:
                return JsonResponse({"success": False, "error": str(e)})
        else:
            return JsonResponse({"success": False, "error": "Invalid topic!"})

def generate_headline(request):
    if request.method == "POST":
        paragraph = request.POST.get("paragraph")
        if paragraph.strip():
            try:
                chat_session = model.start_chat(history=[])
                prompt = f"Generate a catchy headline summarizing the following paragraph:\n\n{paragraph}"
                response = chat_session.send_message(prompt)
                return JsonResponse({"success": True, "text": response.text.strip()})
            except Exception as e:
                return JsonResponse({"success": False, "error": str(e)})
        else:
            return JsonResponse({"success": False, "error": "Invalid paragraph!"})

def enhance_text(request):
    if request.method == "POST":
        text = request.POST.get("text")
        if text.strip():
            try:
                chat_session = model.start_chat(history=[])
                prompt = f"Improve the quality, grammar, and style of the following text:\n\n{text}"
                response = chat_session.send_message(prompt)
                return JsonResponse({"success": True, "text": response.text.strip()})
            except Exception as e:
                return JsonResponse({"success": False, "error": str(e)})
        else:
            return JsonResponse({"success": False, "error": "Invalid text!"})

def humanize_text(request):
    if request.method == "POST":
        ai_text = request.POST.get("ai_text")
        if ai_text.strip():
            try:
                chat_session = model.start_chat(history=[])
                prompt = f"Make the following AI-generated text more human-like and it should bypass AI detection:\n\n{ai_text}"
                response = chat_session.send_message(prompt)
                return JsonResponse({"success": True, "text": response.text.strip()})
            except Exception as e:
                return JsonResponse({"success": False, "error": str(e)})
        else:
            return JsonResponse({"success": False, "error": "Invalid AI text!"})
