# chatbot/forms.py
from django import forms
from .models import UserInfo

class UserNameForm(forms.ModelForm):
    class Meta:
        model = UserInfo
        fields = ['user_name']
